/* 
** Below are the messages used within hypermail that 
** are for user consumption. There are differences
** between user message strings and strings used in
** the HTML and SMTP protocols. Beware not to get
** confused with which is which.
** 
** What follows are a set of defines that act as indices 
** into the specific language array that is setup for
** this list archive. They need to point to the right
** messages in the language arrays or things get interesting.
**
** To add a new language, simply copy an existing language
** array and make the appropriate translations. For example,
** the Spanish language message array has the English message
** as the comment on the side of the message. (It is hoped
** this makes for easier translations... Also make sure and
** add the language to the supported_languages array.
**
** Currently this does not support wide-characters but it is
** a start in the right direction.  
*/

struct language_entry {
    char     *langcode;
    char     **mtable;
};

/* print.c */
#define MSG_NEW_MESSAGE            0
#define MSG_REPLY                  1
#define MSG_ABOUT_THIS_LIST        2
#define MSG_END_OF_MESSAGES        3
#define MSG_START_OF_MESSAGES      4
#define MSG_DATE_VIEW              5
#define MSG_THREAD_VIEW            6
#define MSG_SUBJECT_VIEW           7
#define MSG_AUTHOR_VIEW            8
#define MSG_OTHER_GROUPS           9
#define MSG_MESSAGES              10
#define MSG_STARTING              11
#define MSG_ENDING                12
#define MSG_ABOUT_THIS_ARCHIVE    13
#define MSG_SORTED_BY             14
#define MSG_OTHER_MAIL_ARCHIVES   15
#define MSG_BY_DATE               16
#define MSG_MOST_RECENT_MESSAGES  17
#define MSG_AUTHOR                18
#define MSG_DATE                  19
#define MSG_THREAD                20
#define MSG_SUBJECT               21
#define MSG_FOR_OPTIONS           22
#define MSG_WRITING_ARTICLES      23
#define MSG_WRITING_DATE_INDEX    24
#define MSG_WRITING_THREAD_INDEX  25
#define MSG_WRITING_SUBJECT_INDEX 26
#define MSG_WRITING_AUTHOR_INDEX  27
#define MSG_LAST_MESSAGE_DATE     28
#define MSG_ARCHIVED_ON           29
#define MSG_CANNOT_CHMOD          30
#define MSG_COULD_NOT_WRITE       31
#define MSG_NEXT_MESSAGE          32
#define MSG_PREVIOUS_MESSAGE      33
#define MSG_MAYBE_IN_REPLY_TO     34
#define MSG_IN_REPLY_TO           35
#define MSG_NEXT_IN_THREAD        36
#define MSG_MAYBE_REPLY           37
#define MSG_BY_THREAD             38
#define MSG_BY_SUBJECT            39
#define MSG_BY_AUTHOR             40

/* file.c */
#define MSG_CANNOT_CREATE_DIRECTORY   41
#define MSG_CREATING_DIRECTORY        42
#define MSG_CONFIGURATION_VALUES      43
#define MSG_PATH                      44

/* mem.c */
#define MSG_RAN_OUT_OF_MEMORY         45

/* printfile.c */
#define MSG_ARCHIVE_GENERATED_BY      46

/* struct.c */
#define MSG_ELEMENTS                  47
#define MSG_NO_ELEMENTS               48

/* parse.c */
#define MSG_CANNOT_OPEN_MAIL_ARCHIVE  49
#define MSG_READING_NEW_HEADER        50
#define MSG_LOADING_MAILBOX           51
#define MSG_ENCODING_IS_NOT_SUPPORTED 52
#define MSG_ARTICLES                  53

/* hypermail.c */
#define MSG_VERSION                              54
#define MSG_PATCHLEVEL                           55
#define MSG_DOCS                                 56
#define MSG_COMMAND_AND_CONTROL_VARIABLES        57
#define MSG_YES                                  58
#define MSG_NO                                   59
#define MSG_ABOUT_THE_ARCHIVE_NOT_USED           60
#define MSG_OTHER_ARCHIVES_NOT_USED              61
#define MSG_ADDRESS_NOT_USED                     62
#define MSG_BUILTIN_BODY_STATEMENT_USED          63
#define MSG_CANNOT_READ_FROM_BOTH_FILE_AND_STDIN 64
#define MSG_OPTIONS                              65
#define MSG_OPTION_A                             66
#define MSG_OPTION_B                             67
#define MSG_OPTION_C                             68
#define MSG_OPTION_D                             69
#define MSG_OPTION_I                             70
#define MSG_OPTION_L                             71
#define MSG_OPTION_M                             72
#define MSG_OPTION_P                             73
#define MSG_OPTION_VERBOSE                       74
#define MSG_OPTION_VERSION                       75
#define MSG_OPTION_U                             76
#define MSG_OPTION_X                             77
#define MSG_OPTION_LANG                          78
#define MSG_USAGE                                79
#define MSG_LANGUAGE_NOT_SUPPORTED               80
#define MSG_NOT_SET                              81
#define MSG_NOT_USED                             82
#define MSG_CREATED_ATTACHMENT_FILE              83
#define MSG_ATTACHMENT                           84
#define MSG_MODE                                 85
#define MSG_READING_OLD_HEADERS                  86
#define MSG_OPTIONS_STRING2                      87
#define MSG_ERROR                                88
#define MSG_OPTION_N                             89
#define MSG_OPTION_1                             90
#define MSG_CAUTHOR                		 91
#define MSG_CDATE                  		 92
#define MSG_CSUBJECT               		 93

/* print.c This belong in the first list, but it's quite a lot of work
   to move all the numbers to add them there :-/ How can we simplify
   this work? Jose */
#define MSG_MAIL_ACTIONS                         94
#define MSG_MA_NEW_MESSAGE                       95
#define MSG_MA_REPLY                             96

#ifdef MAIN_FILE

/*
** German version of the language table
*/

[snip]

/*
** English version of the language table
*/

char *en[] = {       /* English */
  "New Message",                 /* New Message        -HTML*/
  "Reply",                       /* Reply              -HTML*/
  "About this list",             /* About this list    -HTML*/
  "End of Messages",             /* End of Messages    -HTML*/
  "Start of Messages",           /* Start of Messages  -HTML*/
  "Date view",                   /* Date view          -HTML*/
  "Thread view",                 /* Thread view        -HTML*/
  "Subject view",                /* Subject view       -HTML*/
  "Author view",                 /* Author view        -HTML*/
  "Other groups",                /* Other groups       -HTML*/
  "Messages",                    /* Messages           -HTML*/
  "Starting",                    /* Starting           -HTML*/
  "Ending",                      /* Ending             -HTML*/
  "About this archive",          /* About this archive -HTML*/
  "sorted by",                   /* Messages sorted by -HTML*/
  "Other mail archives",         /* Other mail archives -HTML*/
  "By Date",                     /* By Date             -HTML*/
  "Most recent messages",        /* Most recent messages-HTML*/
  "author",                      /* author              -HTML*/
  "date",                        /* date                -HTML*/
  "thread",                      /* thread              -HTML*/
  "subject",                     /* subject             -HTML*/
  "for options",                 /* for options       -STDOUT*/
  "Writing messages to",         /* Writing messages to-STDOUT*/
  "Writing date index to",       /* Writing date index to-STDOUT*/
  "Writing thread index to",     /* Writing thread index to -STDOUT*/
  "Writing subject index to",    /* Writing subject index to-STDOUT*/
  "Writing author index to",     /* Writing author index to-STDOUT*/
  "Last message date",           /* Last message date   -HTML*/
  "Archived on",                 /* Archived on         -HTML*/
  "Can not chmod",               /* Can not chmod     -STDERR*/
  "Could not write",             /* Could not write   -STDERR*/
  "Next message",                /* Next message        -HTML*/
  "Previous message",            /* Previous message    -HTML*/
  "Maybe in reply to",           /* Maybe in reply to   -HTML*/
  "In reply to",                 /* In reply to         -HTML*/
  "Next in thread",              /* Next in thread      -HTML*/
  "Maybe reply",                 /* Maybe reply         -HTML*/
  "By Thread",                   /* By Thread           -HTML*/
  "By Subject",                  /* By Subject          -HTML*/
  "By Author",                   /* By Author           -HTML*/
  "Can not create directory",    /* Can not create directory -STDERR*/
  "Creating directory",          /* Creating directory -STDOUT*/
  "Configuration Values",        /* Configuration Values -STDOUT*/
  "path",                        /* path              -STDOUT*/
  "Ran out of memory!",          /* Ran out of memory!-STDERR*/
  "This archive was generated by",  /* This archive was generated by-HTML*/
  "Elements",                    /* Elements          -STDOUT*/
  "No Elements",                 /* No Elements       -STDOUT*/
  "Cannot open mail archive",    /* Cannot open mail archive */
  "Reading new header...",       /* Reading new header...-STDOUT   */
  "Loading mailbox",             /* Loading mailbox      -STDOUT   */
  "encoding is not supported, stored as-is", /* encoding is not supported, stored as-is -HTML*/
  "messages",                    /* messages             -HTML*/
  "Version",                     /* Version            -STDOUT*/
  "Patchlevel",                  /* Patchlevel         -STDOUT*/
  "Docs",                        /* Docs               -STDOUT*/
  "Command and Control Variables",       /* Command and Control Variables-STDOUT*/
  "Yes",                         /* Yes                -STDOUT*/
  "No",                          /* No                 -STDOUT*/
  "About the archive: not used", /* About the archive: not used-STDOUT */
  "Other archives: not used",    /* Other archives: not used-STDOUT*/
  "address not used",            /* address not used        -STDOUT*/
  "Builtin <BODY> statement used", /* Builtin <BODY> statement used-STDOUT*/
  "Cannot read from both file and stdin.", /* Cannot read from both file and stdin. -STDERR*/
  "Options",                     /* Options                -STDOUT*/
  "URL to other archives",       /* URL to other archives  -STDOUT*/
  "URL to archive information",  /* URL to archive information -STDOUT*/
  "Configuration file to read in", /* Configuration file to read in -STDOUT*/
  "The directory to save HTML files in", /* The directory to save HTML files in -STDOUT*/
  "Read messages from standard input",/* Read messages from standard input -STDOUT*/
  "What to name the output archive", /* What to name the output archive -STDOUT*/
  "Mail archive to read in",     /* Mail archive to read in -STDOUT*/
  "Show progress",               /* Show progress           -STDOUT*/
  "Show configuration variables only", /* Show configuration variables only -STDOUT*/
  "Show version information and exit", /* Show version information and exit -STDOUT*/
  "Update archive by one article", /* Update archive by one article -STDOUT*/
  "Overwrite previous messages", /* Overwrite previous messages -STDOUT*/
  "Specify language to use",     /* Specify language to use     -STDOUT*/
  "Usage",                       /* Usage                       -STDOUT*/
  "Language not supported",      /* Language not supported      -STDERR*/
  "Not set",                     /* Not set                     -STDOUT*/
  "Not used",                    /* Not used                    -STDOUT*/
  "Created attachment file",     /* Created attachment file     -STDOUT*/
  "attachment",                  /* attachment                    -HTML*/
  "mode",                        /* mode                        -STDOUT*/
  "Reading old headers",         /* Reading old headers         -STDOUT*/
  "", /* for alignment only       -STDOUT*/
  "ERROR",                       /* ERROR                       -STDERR*/
  "The submission address of the list", 
                           /* The submission address of the list-STDERR*/
  "Read only one mail from input",
  "Author",                      /* author              -HTML*/
  "Date",                        /* date                -HTML*/
  "Subject",                     /* subject             -HTML*/
  "Mail actions",                /* Mail actions (MA) header -HTML*/
  "mail a new topic",            /* MA New Message      -HTML*/
  "respond to this message",     /* MA Reply            -HTML*/
  NULL,                          /* End Of Message Table      - NOWHERE*/
};

/*
** Spanish version of the language table
*/

[snip]

/*
** Finnish version of the language table
*/

[snip]

/*
** French version of the language table
*/

[snip]

/*
** Icelandic version of the language table
*/

[snip]

/*
** Swedish version of the language table. Daniel Stenberg translation.
*/

[snip]

/*
** Italian version of the language table
*/

char *it[] = {       /* Italian */
  "Nuovo Messaggio",                 /* New Message        -HTML*/
  "Risposta",                       /* Reply              -HTML*/
  "Su questa lista",             /* About this list    -HTML*/
  "Fine dei messaggi",             /* End of Messages    -HTML*/
  "Inizio dei messaggi",           /* Start of Messages  -HTML*/
  "Vista per data",                   /* Date view          -HTML*/
  "Vista per thread",                 /* Thread view        -HTML*/
  "Vista per soggetto",                /* Subject view       -HTML*/
  "Vista per autore",                 /* Author view        -HTML*/
  "Altri gruppi",                /* Other groups       -HTML*/
  "Messaggi",                    /* Messages           -HTML*/
  "Dal",                    /* Starting           -HTML*/
  "Al",                      /* Ending             -HTML*/
  "Su questo archivio",          /* About this archive -HTML*/
  "ordinati per",                   /* Messages sorted by -HTML*/
  "Altri archivi di posta",         /* Other mail archives -HTML*/
  "Per data",                     /* By Date             -HTML*/
  "Messaggi pi� recenti",        /* Most recent messages-HTML*/
  "autore",                      /* author              -HTML*/
  "data",                        /* date                -HTML*/
  "thread",                      /* thread              -HTML*/
  "soggetto",                     /* subject             -HTML*/
  "per opzioni",                 /* for options       -STDOUT*/
  "Scrivo i messaggi su",         /* Writing messages to-STDOUT*/
  "Scrivo l'indice per data su",       /* Writing date index to-STDOUT*/
  "Scrivo l'indice per thread su",     /* Writing thread index to -STDOUT*/
  "Scrivo l'indice per subject su",    /* Writing subject index to-STDOUT*/
  "Scrivo l'indice per autore su",     /* Writing author index to-STDOUT*/
  "Data dell' ultimo messaggio",           /* Last message date   -HTML*/
  "Archiviato il",                 /* Archived on         -HTML*/
  "Impossibile eseguire chmod",               /* Can not chmod     -STDERR*/
  "Impossibile scrivere",             /* Could not write   -STDERR*/
  "Prossimo messaggio",                /* Next message        -HTML*/
  "Messaggio precedente",            /* Previous message    -HTML*/
  "Forse in risposta a",           /* Maybe in reply to   -HTML*/
  "In risposta a",                 /* In reply to         -HTML*/
  "Prossimo nel thread",              /* Next in thread      -HTML*/
  "Forse risposta",                 /* Maybe reply         -HTML*/
  "Per Thread",                   /* By Thread           -HTML*/
  "Per Soggetto",                  /* By Subject          -HTML*/
  "Per Autore",                   /* By Author           -HTML*/
  "Impossibile creare la directory",    /* Can not create directory -STDERR*/
  "Creo la directory",          /* Creating directory -STDOUT*/
  "Valori di Configurazione",        /* Configuration Values -STDOUT*/
  "percorso",                        /* path              -STDOUT*/
  "Memoria esaurita!",          /* Ran out of memory!-STDERR*/
  "Questo archivio � stato generato da",  /* This archive was generated by-HTML*/
  "Elementi",                    /* Elements          -STDOUT*/
  "Nessun Elemento",                 /* No Elements       -STDOUT*/
  "impossibile aprire l' archivio di posta",    /* Cannot open mail archive */
  "Leggo un nuovo header...",       /* Reading new header...-STDOUT   */
  "Carico la mailbox",             /* Loading mailbox      -STDOUT   */
  "codifica non supportata, memorizzato cos� com'�", /* encoding is not supported, stored as-is -HTML*/
  "messaggi",                    /* messages             -HTML*/
  "Versione",                     /* Version            -STDOUT*/
  "Patchlevel",                  /* Patchlevel         -STDOUT*/
  "Documenti",                        /* Docs               -STDOUT*/
  "Comando e Variabili di Controllo",       /* Command and Control Variables-STDOUT*/
  "Si",                         /* Yes                -STDOUT*/
  "No",                          /* No                 -STDOUT*/
  "Sull' archivio: non usato", /* About the archive: not used-STDOUT */
  "Altri archivi: non usato",    /* Other archives: not used-STDOUT*/
  "indirizzo non usato",            /* address not used        -STDOUT*/
  "Usato lo statement <BODY> interno", /* Builtin <BODY> statement used-STDOUT*/
  "Impossibile leggere da entrambi file e stdin.", /* Cannot read from both file and stdin. -STDERR*/
  "Opzioni",                     /* Options                -STDOUT*/
  "URL ad altri archivi",       /* URL to other archives  -STDOUT*/
  "URL ad informazioni sull' archivio",  /* URL to archive information -STDOUT*/
  "File di configurazione da cui leggere", /* Configuration file to read in -STDOUT*/
  "Directory in cui salvare i file HTML", /* The directory to save HTML files in -STDOUT*/
  "Legge i messaggi dallo standard input",/* Read messages from standard input -STDOUT*/
  "Come chiamare l' archivo di output", /* What to name the output archive -STDOUT*/
  "Archivio di posta da cui leggere",     /* Mail archive to read in -STDOUT*/
  "Mostra il progresso",               /* Show progress           -STDOUT*/
  "Mostra solo le variabili di configurazione", /* Show configuration variables only -STDOUT*/
  "Mostra informazioni sulla versione ed esci", /* Show version information and exit -STDOUT*/
  "Aggiorna l' archivio di un articolo", /* Update archive by one article -STDOUT*/
  "sovrascrivi i messaggi precedenti", /* Overwrite previous messages -STDOUT*/
  "Specifica il linguaggio da usare",     /* Specify language to use     -STDOUT*/
  "Utilizzo",                       /* Usage                       -STDOUT*/
  "Linguaggio non supportato",      /* Language not supported      -STDERR*/
  "Non settato",                     /* Not set                     -STDOUT*/
  "Non usato",                    /* Not used                    -STDOUT*/
  "File di attachment creato",     /* Created attachment file     -STDOUT*/
  "attachment",                  /* attachment                    -HTML*/
  "modo",                        /* mode                        -STDOUT*/
  "Leggo i vecchi header",         /* Reading old headers         -STDOUT*/
  "", /* for alignment only       -STDOUT*/
  "ERRORE",                       /* ERROR                       -STDERR*/
  "L' indirizzo per scrivere alla lista", 
                           /* The submission address of the list-STDERR*/
  "Leggi una sola mail da input",
  "Autore",                      /* author              -HTML*/
  "Data",                        /* date                -HTML*/
  "Soggetto",                     /* subject             -HTML*/
  "Azioni Posta",                /* Mail actions (MA) header -HTML*/
  "Scrivi un nuovo topic",            /* MA New Message      -HTML*/
  "riscpondi a questo messaggio",     /* MA Reply            -HTML*/
  NULL,                          /* End Of Message Table      - NOWHERE*/
};

/*
** list of supported languages
*/

struct language_entry ltable[] = {
{    "de",      de   },     /* German  */
{    "en",      en   },     /* English */
{    "es",      es   },     /* Spanish */
{    "fi",      fi   },     /* Finnish */
{    "fr",      fr   },     /* French  */
{    "is",      is   },     /* Icelandic */
{    "se",      se   },     /* Swedish */
{    "it",      it   },     /* Italian */
{     NULL,     NULL },     /* EOL     */
};

/*
** Default language table
*/
char **lang = en;

#else

extern char **lang;
extern struct language_entry ltable[];

#endif
